from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'Password.123456'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33792        # <- MongoDB default port
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}/?directConnection=true&authSource=admin')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a new document into the collection."""
        if data:
            try:
                result = self.collection.insert_one(data)
                return True if result.acknowledged else False
            except Exception as e:
                print(f"Insert failed: {e}")
                return False
        else:
            raise ValueError("Nothing to save, data parameter is empty")

    def read(self, query):
        """Read documents matching the query from the collection."""
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"Read failed: {e}")
            return []
        
    def update(self, query, new_values):
        """Update document(s) matching the query with new values."""
        try:
            update_result = self.collection.update_many(query, {'$set': new_values})
            return update_result.modified_count
        except Exception as e:
            print(f"Update failed: {e}")
            return 0

    def delete(self, query):
        """Delete document(s) matching the query."""
        try:
            delete_result = self.collection.delete_many(query)
            return delete_result.deleted_count
        except Exception as e:
            print(f"Delete failed: {e}")
            return 0